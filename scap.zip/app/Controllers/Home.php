<?php

namespace App\Controllers;
use App\Models\UsuarioModel;
use App\Models\AsistenciaModel;

class Home extends BaseController
{
    public function index()
    {
        $tab_usuario = new UsuarioModel();

        $fa = date('Y-m-d');

        $query = $this->db->query("SELECT *
            FROM asistencia a 
            INNER JOIN usuario u ON u.usu_id = a.usu_id
            WHERE a.asi_fecha = '$fa'
            ORDER BY a.asi_id DESC");
        $dato_usuario = $query->getResultArray();

        $datos = array(
            'usuario' => $dato_usuario
        );

        return view('index', $datos);
    }
//session
    public function login(){
        $tab_usuario = new UsuarioModel();
        $tab_asistencia = new AsistenciaModel();

        $usu = $this->request->getPost('ci');

        $dat_usu = $tab_usuario->where('usu_ci', $usu)->findAll();

        if ($dat_usu) {
            switch ($dat_usu[0]['usu_tipo']) {
                case '1':
                    $data = [
                        "tipo" => $dat_usu[0]['usu_tipo'],
                        "id" => $dat_usu[0]['usu_id'],
                        "nombre" => $dat_usu[0]['usu_nombre'].'  '.$dat_usu[0]['usu_ap_paterno'].' '.$dat_usu[0]['usu_ap_materno']
                    ];
                    $session = session();

                    $session->set($data);
                    return redirect()->to(base_url('panel'))->with('msg', ['tipo'=>'success', 'mensaje'=>'BIENVENIDO '.$dat_usu[0]['usu_nombre'].'  '.$dat_usu[0]['usu_ap_paterno'].' '.$dat_usu[0]['usu_ap_materno']]);
                    break;
                case '2':
                    $nom = $dat_usu[0]['usu_nombre'];
                    $u = $dat_usu[0]['usu_id'];
                    $fa = date('Y-m-d');
                    $ha = date(' H:i:s');

                    $query = $this->db->query("SELECT *
                        FROM asistencia
                        WHERE usu_id = $u AND asi_fecha = '$fa'");
                    $dat_asi = $query->getResultArray();

                    if($dat_asi){
                        $can = count($dat_asi);
                        if ($can == 1) {
                            $data = [
                                'usu_id' => $u,
                                'asi_fecha' => $fa,
                                'asi_hora' => $ha,
                                'asi_tipo' => 2
                            ];
                            $tab_asistencia->insert($data);
                            return redirect()->back()->with('msg', ['tipo'=>'success', 'mensaje'=>'REGISTRO DE SALIDA EXITOSA']);
                        }else{
                            return redirect()->back()->with('msg', ['tipo'=>'info', 'mensaje'=>'El usuario ya registro su entrada y salida']);
                        }
                    }else{
                        $data = [
                            'usu_id' => $u,
                            'asi_fecha' => $fa,
                            'asi_hora' => $ha,
                            'asi_tipo' => 1
                        ]; 
                        $tab_asistencia->insert($data);
                        return redirect()->back()->with('msg', ['tipo'=>'success', 'mensaje'=>'REGISTRO DE INGRESO EXITOSO']);
                    }
                break;
            }
            
        }else{
            return redirect()->to(base_url('/'))->with('msg', ['tipo'=>'error', 'mensaje'=>'Usuario no registrado']);
        }
        return redirect()->to(base_url('/'));
    }
    //registro de usuario
    public function registro(){
        echo view('registro');
    }
    public function nuevoRegistro(){
        $tab_usuario = new UsuarioModel();

        $nom = mb_strtoupper($this->request->getPost('nombre'));
        $app = mb_strtoupper($this->request->getPost('ap_pat'));
        $apm = mb_strtoupper($this->request->getPost('ap_mat'));
        $ced = $this->request->getPost('ci');
        $cel = mb_strtoupper($this->request->getPost('celular'));
        $ins = mb_strtoupper($this->request->getPost('instituto'));
        $car = mb_strtoupper($this->request->getPost('carrera'));
        $tie = $this->request->getPost('tiempo');

        $data = [
            'usu_nombre' => $nom,
            'usu_ap_paterno' => $app,
            'usu_ap_materno' => $apm,
            'usu_ci' => $ced,
            'usu_celular' => $cel,
            'usu_instituto' => $ins,
            'usu_carrera' => $car,
            'usu_tiempo' => $tie
        ];
        $tab_usuario->insert($data);

        return redirect()->to(base_url('/'))->with('msg', ['tipo'=>'success', 'mensaje'=>'Usuario registrado exitosamente']);
    }
    //cerrar sesion
    public function salir(){
        $session = session();
        $session->destroy();
        return redirect()->to(base_url('/'));
    }
//panel
    public function panel(){
        $pag = ['pag' => 'pri'];
        echo view('admin/header', $pag);
        echo view('admin/panel');
        echo view('admin/footer');
    }
    //usuarios
    public function usuario(){
        $tab_usuario = new UsuarioModel();
        $pag = ['pag' => 'usu'];

        $dato_usuario = $tab_usuario->where('usu_tipo', 2)->findAll();

        $datos = array(
            'usuario' => $dato_usuario
        );

        echo view('admin/header', $pag);
        echo view('admin/usuario', $datos);
        echo view('admin/footer');
    }
    //nuevo usuario
    public function nuevoUsuario(){
        $tab_usuario = new UsuarioModel();

        $nom = mb_strtoupper($this->request->getPost('nombre'));
        $app = mb_strtoupper($this->request->getPost('ap_pat'));
        $apm = mb_strtoupper($this->request->getPost('ap_mat'));
        $ced = $this->request->getPost('ci');
        $cel = mb_strtoupper($this->request->getPost('celular'));
        $ins = mb_strtoupper($this->request->getPost('instituto'));
        $car = mb_strtoupper($this->request->getPost('carrera'));
        $tie = $this->request->getPost('tiempo');

        $data = [
            'usu_nombre' => $nom,
            'usu_ap_paterno' => $app,
            'usu_ap_materno' => $apm,
            'usu_ci' => $ced,
            'usu_celular' => $cel,
            'usu_instituto' => $ins,
            'usu_carrera' => $car,
            'usu_tiempo' => $tie
        ];
        $tab_usuario->insert($data);

        return redirect()->back()->with('msg', ['tipo'=>'success', 'mensaje'=>'Usuario registrado exitosamente']);
    }
    //editar usuario
    public function editarUsuario(){

    }
    //ajax
    public function AJAX(){
        $db = \Config\Database::connect();

        if($this->request->getVar('act'))
        {
            $act = $this->request->getVar('act');

            //tipo de intervencion
                if($act == 'get_usu')
                {  
                    $usu = $this->request->getVar('u');
                    $query = $db->query("SELECT *
                        FROM usuario 
                        WHERE usu_id = $usu");
                    $dato = $query->getResultArray();

                    echo json_encode($dato);
                }
        }
    }
}
