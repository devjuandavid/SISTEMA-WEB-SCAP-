<!-- main -->
<div class="main-content container-fluid">
    <div class="page-title">
        <h4 class="mb-4">PANEL PRINCIPAL</h4>
    </div>
    <section class="section">
      <!-- tabla -->
        <div class="row mb-4">
          <div class="col-md-12">
            <div class="card p-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="card-title">Lista de usuarios</h4>
                    <div class="d-flex ">
                        <i data-feather="download"></i>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="table-responsive">
                        <table class='table mb-0' id="tabla">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>City</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Graiden</td>
                                    <td>vehicula.aliquet@semconsequat.co.uk</td>
                                    <td>076 4820 8838</td>
                                    <td>Offenburg</td>
                                    <td>
                                        <span class="badge bg-success">Active</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
          </div>
        </div>
    </section>
</div>
<!-- fin main -->

<!-- script -->
  <script>
    $(document).ready(function() {
      $('#tabla').DataTable({

      });
    });
  </script>
<!-- fin de script -->