            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-left">
                        <p><?= date('Y') ?> SUBDIRECCIÓN DE EDUCACIÓN SUPERIOR DE FORMACIÓN PROFESIONAL</p>
                    </div>
                    <div class="float-right">
                        <p>Desarrollado <span class='text-danger'><i data-feather="heart"></i></span> por <a href="https://kernelbolivia.com/">Kernel Bolivia</a></p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="<?= base_url() ?>/public/assets/js/feather-icons/feather.min.js"></script>
    <script src="<?= base_url() ?>/public/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url() ?>/public/assets/js/app.js"></script>
    <script src="<?= base_url() ?>/public/assets/fontawesome/js/all.js"></script>
    
    <script src="<?= base_url() ?>/public/assets/vendors/chartjs/Chart.min.js"></script>
    <script src="<?= base_url() ?>/public/assets/vendors/apexcharts/apexcharts.min.js"></script>
    <script src="<?= base_url() ?>/public/assets/js/pages/dashboard.js"></script>

    <script src="<?= base_url() ?>/public/assets/js/main.js"></script>
    <!-- Datatable -->
    <script src="<?= base_url() ?>/public/assets/datatable/datatables.js"></script>
</body>
</html>