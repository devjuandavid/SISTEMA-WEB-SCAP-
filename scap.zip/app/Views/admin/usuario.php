<!-- main -->
  <div class="main-content container-fluid">
      <div class="page-title">
          <h4 class="mb-4">USUARIOS</h4>
      </div>
      <section class="section">
        <!-- tabla -->
          <div class="row mb-4">
            <div class="col-md-12">
              <div class="card p-3">
                  <div class="card-header">
                      <div class="row">
                          <div class="col-md-8">
                              <h4 class="card-title">Lista de usuarios</h4>
                          </div>
                          <div class="col-md-4">
                              <button class="btn btn-primary w-100" data-toggle="modal" data-target="#nuevo">NUEVO USUARIO</button>
                          </div>
                      </div>
                  </div>
                  <div class="card-body px-0 pb-0">
                      <div class="table-responsive">
                          <table class='table mb-0' id="tabla" style="font-size: 13px;">
                              <thead>
                                  <tr>
                                      <th>Nombre y CI</th>
                                      <th>Instituto y Carrera</th>
                                      <th>Celular y Tiempo</th>
                                      <th>Estado</th>
                                      <th class="text-center">Acciones</th>
                                  </tr>
                              </thead>
                              <tbody>
                                <?php foreach ($usuario as $dato): ?>
                                  <tr>
                                      <td>
                                          <p class="mb-0"><?= $dato['usu_nombre'].' '.$dato['usu_ap_paterno'].' '.$dato['usu_ap_materno'] ?></p>
                                          <p class="text-secondary"><?= $dato['usu_ci'] ?></p>
                                      </td>
                                      <td>
                                          <p class="mb-0"><?= $dato['usu_instituto'] ?></p>
                                          <p class="text-secondary"><?= $dato['usu_carrera'] ?></p>
                                      </td>
                                      <td>
                                          <p class="mb-0"><?= $dato['usu_celular'] ?></p>
                                          <p class="text-secondary"><?php switch($dato['usu_tiempo']) {
                                            case '1':
                                              echo 'MEDIO TIEMPO';
                                              break;
                                            case '2':
                                              echo 'TIEMPO COMPLETO';
                                              break;
                                          } ?></p>
                                      </td>
                                      <td>
                                          <?php switch ($dato['usu_estado']) {
                                            case '0':
                                              echo "<span class='badge bg-danger small'>BLOQUEADO</span>";
                                              break;
                                            case '1':
                                              echo "<span class='badge bg-success small'>ACTIVO</span>";
                                              break;
                                          }?>
                                      </td>
                                      <td class="text-center">
                                        <button onclick="editar(<?= $dato['usu_id'] ?>)" class="btn btn-warning px-2"><i class="fa-solid fa-pen-to-square"></i></button>
                                        <button onclick="editar(<?= $dato['usu_id'] ?>)" class="btn btn-danger px-2"><i class="fa-regular fa-trash-can"></i></button>
                                      </td>
                                  </tr>
                                <?php endforeach ?>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
            </div>
          </div>
      </section>
  </div>
<!-- fin main -->

<!-- modal -->
  <!-- nuevo -->
    <div class="modal fade" id="nuevo" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <form id="formulario" action="<?= base_url('new-usu') ?>" method="post">
            <div class="modal-header">
              <h6 class="modal-title" id="staticBackdropLabel">NUEVO USUARIO</h6>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span class="h4" aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body ovf">

              <div class="row">
                <!-- nombre -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nombre</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Nombre" id="first-name-icon" name="nombre" autocomplete="off" pattern=".{3,100}" title="Datos alfabéticos entre 3 a 100 caracteres" required>
                            <div class="form-control-icon">
                                <i class="fa-solid fa-signature"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- apellido paterno -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Apellido paterno</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Apellido paterno" id="first-name-icon" name="ap_pat" pattern=".{3,100}" title="Datos alfabéticos entre 3 a 100 caracteres"  autocomplete="off">
                            <div class="form-control-icon">
                                <i class="fa-solid fa-signature"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- apellido materno -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Apellido materno</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Apellido materno" id="first-name-icon" name="ap_mat" pattern=".{3,100}" title="Datos alfabéticos entre 3 a 100 caracteres"  autocomplete="off">
                            <div class="form-control-icon">
                                <i class="fa-solid fa-signature"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ci -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cédula de identidad</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Cédula de identidad" id="first-name-icon" name="ci" autocomplete="off" pattern=".{5,25}" title="Datos alfanuméricos entre 5 a 25 caracteres"  required>
                            <div class="form-control-icon">
                                <i class="fa-regular fa-id-card"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- celular -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Número celular</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Número celular" id="first-name-icon" name="celular" autocomplete="off" pattern="[0-9]{8}" title="Datos numéricos de 8 dígitos" required>
                            <div class="form-control-icon">
                                <i class="fa-solid fa-mobile-screen"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- instituto -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Instituto</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Instituto" id="first-name-icon" name="instituto" autocomplete="off" pattern=".{5,250}" title="Datos alfanuméricos entre 5 a 250 caracteres" required>
                            <div class="form-control-icon">
                                <i class="fa-solid fa-building-columns"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- carrera -->
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Carrera</font></font></label>
                </div>
                <div class="col-md-8">
                    <div class="form-group has-icon-left">
                        <div class="position-relative">
                            <input type="text" class="form-control" placeholder="Carrera" id="first-name-icon" name="carrera" autocomplete="off" pattern=".{5,250}" title="Datos alfanuméricos entre 5 a 250 caracteres" required>
                            <div class="form-control-icon">
                                <i class="fa-solid fa-folder-tree"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tiempo</font></font></label>
                </div>
                <div class="col-md-8">
                  <div class="input-group mb-3">
                      <label class="input-group-text" for="tiempo"><i class="fa-solid fa-calendar-days"></i></label>
                      <select class="form-select" id="tiempo">
                          <option selected="">Seleccionar...</option>
                          <option value="1">Medio tiempo</option>
                          <option value="2">Tiempo completo</option>
                      </select>
                  </div>
                </div>
              </div>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">CANCELAR</button>
              <button id="button" type="submit" class="btn btn-primary">REGISTRAR</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  <!-- editar -->
    <div class="modal fade" id="editar" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" id="cont_editar">

        </div>
      </div>
    </div>
<!-- fin modal -->

<!-- script -->
  <script>
    //editar
    function editar(e){
      var con = document.getElementById('cont_editar');

      $.ajax({
        url:"<?= base_url('/Home/AJAX') ?>",
        method:"POST",
        data:{u:e, act:'get_usu'},
        cache: false,
        dataType:"json",
        success:function(data){
          //llenar modal
          con.innerHTML = `
            <form action="<?= base_url('edi-com?c=') ?>" method="post">
              <div class="modal-header">
                <h6 class="modal-title" id="staticBackdropLabel">EDITAR USUARIO</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span class="h4" aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body ovf">

                <div class="row">
                  <!-- nombre -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nombre</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Nombre" id="first-name-icon" name="nombre" autocomplete="off" pattern=".{3,100}" title="Datos alfabéticos entre 3 a 100 caracteres" required>
                              <div class="form-control-icon">
                                  <i class="fa-solid fa-signature"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- apellido paterno -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Apellido paterno</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Apellido paterno" id="first-name-icon" name="ap_pat" pattern=".{3,100}" title="Datos alfabéticos entre 3 a 100 caracteres"  autocomplete="off">
                              <div class="form-control-icon">
                                  <i class="fa-solid fa-signature"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- apellido materno -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Apellido materno</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Apellido materno" id="first-name-icon" name="ap_mat" pattern=".{3,100}" title="Datos alfabéticos entre 3 a 100 caracteres"  autocomplete="off">
                              <div class="form-control-icon">
                                  <i class="fa-solid fa-signature"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- ci -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cédula de identidad</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Cédula de identidad" id="first-name-icon" name="ci" autocomplete="off" pattern=".{5,25}" title="Datos alfanuméricos entre 5 a 25 caracteres"  required>
                              <div class="form-control-icon">
                                  <i class="fa-regular fa-id-card"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- celular -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Número celular</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Número celular" id="first-name-icon" name="celular" autocomplete="off" pattern="[0-9]{8}" title="Datos numéricos de 8 dígitos" required>
                              <div class="form-control-icon">
                                  <i class="fa-solid fa-mobile-screen"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- instituto -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Instituto</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Instituto" id="first-name-icon" name="instituto" autocomplete="off" pattern=".{5,250}" title="Datos alfanuméricos entre 5 a 250 caracteres" required>
                              <div class="form-control-icon">
                                  <i class="fa-solid fa-building-columns"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <!-- carrera -->
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Carrera</font></font></label>
                  </div>
                  <div class="col-md-8">
                      <div class="form-group has-icon-left">
                          <div class="position-relative">
                              <input type="text" class="form-control" placeholder="Carrera" id="first-name-icon" name="carrera" autocomplete="off" pattern=".{5,250}" title="Datos alfanuméricos entre 5 a 250 caracteres" required>
                              <div class="form-control-icon">
                                  <i class="fa-solid fa-folder-tree"></i>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4">
                      <label><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tiempo</font></font></label>
                  </div>
                  <div class="col-md-8">
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="tiempo"><i class="fa-solid fa-calendar-days"></i></label>
                        <select class="form-select" id="tiempo">
                            <option selected="">Seleccionar...</option>
                            <option value="1">Medio tiempo</option>
                            <option value="2">Tiempo completo</option>
                        </select>
                    </div>
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">CANCELAR</button>
                <button type="submit" class="btn btn-primary">EDITAR</button>
              </div>
            </form>
          `;
        },

        error:function(data){
          con.innerHTML = `<form action="<?= base_url('edi-usu') ?>" method="post" enctype="multipart/form-data">
              <div class="modal-header">
                <h6 class="modal-title" id="staticBackdropLabel">EDITAR USUARIO</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span class="h4" aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body ovf">
                ERROR: DATOS NO ENCONTRADO
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">CANCELAR</button>
              </div>
            </form>`; 
        }
      });

      //mostrar modal
      $('#editar').modal('show');
    }
    //table
        $(document).ready(function() {
          $('#tabla').DataTable({
            ordering: false
          });
        });
  </script>
<!-- fin de script -->